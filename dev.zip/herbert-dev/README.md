Herbert
===============

Welcome to Herbert. Please check out the docs [here](http://getherbert.com/).

Check out the example plugin [here](https://github.com/getherbert/example-plugin).

You can find a full plugin built in Herbert [here](https://github.com/bigbitecreative/wordpress-socializr).

---
If you are looking for the old version, you can find it here: https://github.com/getherbert/herbert/tree/pre
And the docs for that version: http://getherbert.com/pre


