<?php

/**
 * @wordpress-plugin
 * Plugin Name:       MyPlugin
 * Plugin URI:        http://plugin-name.com/
 * Description:       A plugin.
 * Version:           1.0.0
 * Author:            Author
 * Author URI:        http://author.com/
 * License:           MIT
 */

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/vendor/getherbert/framework/bootstrap/autoload.php';
