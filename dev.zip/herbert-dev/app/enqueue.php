<?php namespace MyPlugin;

/** @var \Herbert\Framework\Enqueue $enqueue */

