<?php namespace MyPlugin;

/** @var \Herbert\Framework\Widget $widget */
