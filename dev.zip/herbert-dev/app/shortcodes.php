<?php namespace MyPlugin;

/** @var \Herbert\Framework\Shortcode $shortcode */
