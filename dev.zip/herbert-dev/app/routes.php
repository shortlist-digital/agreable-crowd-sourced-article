<?php namespace MyPlugin;

/** @var \Herbert\Framework\Router $router */
