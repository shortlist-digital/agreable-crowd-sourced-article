<?php namespace MyPlugin;

/** @var \Herbert\Framework\Panel $panel */
